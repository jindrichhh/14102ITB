public static Scanner sc = new Scanner(System.in);
    public static int pole[];
    public static int pole2[];
    public static int pole3[];

    public static void main(String[] args) 
    {
        Napln();
        RozdelitAPorovnat();
        Vypis();
    }


    public static void Vypis()
    {
        for (int i = 0; i < pole.length; i++) {
            if(i == pole.length - 1)
            {
                System.out.println(pole2[i]);
                System.out.println(pole3[i]);
            }
            else
            {
                System.out.println(pole2[i] + " , ");
                System.out.println(pole3[i] + " , ");
            }
        }
    }

    public static void Napln()
    {
        System.out.println("Velikost pole: ");
        pole = new int[sc.nextInt()];
        for (int i = 0; i < pole.length; i++) {
            System.out.println("Zadejte cislo: ");
            pole[i] = sc.nextInt();
        }
    }

    public static void RozdelitAPorovnat()
    {
        int x = pole.length / 2;
        pole2 = new int[x];
        pole3 = new int[x];
        for (int i = 0; i < pole2.length; i++) {
            pole2[i] = pole[pole.length - i];
        }
        for (int i = 0; i < pole3.length; i++) {
            pole2[i] = pole[i];

        }
    }