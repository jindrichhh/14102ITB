public static Scanner sc = new Scanner(System.in);
    public static int pole[];
    public static int pole2[];
    public static int pole3[];
    
    public static void main(String[] args) 
    {
        Napln();
        Rozdelit();
        Vypis();
    }
   
   
    public static void Vypis()
    {
        System.out.println(Arrays.toString(pole2));
        System.out.println(Arrays.toString(pole3));
        int x = 0;
        int y = 0;
        for (int i = 0; i < pole2.length; i++) {
            x += pole2[i];
            y += pole3[i];
        }
        if(x > y)
        {
            System.out.println(Arrays.toString(pole2) + " Je vetsi");
        }
        else
        {
            System.out.println(Arrays.toString(pole3) + " Je vetsi");
        }
        
    }
    
    public static void Napln()
    {
        System.out.println("Velikost pole: ");
        pole = new int[sc.nextInt()];
        for (int i = 0; i < pole.length; i++) {
            System.out.println("Zadejte cislo: ");
            pole[i] = sc.nextInt();
        }
    }
    
    public static void Rozdelit()
    {
        int x = pole.length / 2;
        pole2 = new int[x];
        pole3 = new int[x];
        int xx=1;
        for (int i = 0; i < x; i++) {          
            pole2[i] = pole[pole.length - xx];
            xx++;
        }
        for (int i = 0; i < x; i++) {
            pole3[i] = pole[i];
        }
    }